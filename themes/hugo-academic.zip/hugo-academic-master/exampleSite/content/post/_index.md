+++
title = "Posts"
date = 2017-01-01T00:00:00
math = false
highlight = false

# List format.
#   0 = Simple
#   1 = Detailed
list_format = 1

# Optional featured image (relative to `static/img/` folder).
[header]
image = ""
caption = ""
+++
