+++
# Recent Posts widget.
# This widget displays recent posts from `content/post/`.
widget = "posts"
active = true
date = 2016-04-20T00:00:00

title = "Recent Posts"
subtitle = ""

# Order that this section will appear in.
weight = 40

# Filter posts by tag.
#  By default, show all recent posts.
#  Filtering example: `tags_include = ["hugo", "academic"]`
tags_include = []
tags_exclude = []

# Number of posts to list.
count = 5

# List format.
#   0 = Simple
#   1 = Detailed
list_format = 1
+++

